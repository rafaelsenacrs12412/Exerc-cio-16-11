import { createRouter, createWebHashHistory } from 'vue-router';
import PaginaAgenda from './pages/PaginaAgenda.vue';

const rotas = [
    { path: '/', component: PaginaAgenda },
];

export const router = createRouter({
    history: createWebHashHistory(),
    routes: rotas
});